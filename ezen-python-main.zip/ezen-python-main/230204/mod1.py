## 변수 생성
x = "module test"

## 함수 생성
def func_1(a, b):
    return a+b

## 클래스 생성
class Class_1():
    def __init__(self, input_data):
        self.data = input_data

    def view_data(self):
        return f"Class에서 입력받은 data의 값은 {self.data}이다"