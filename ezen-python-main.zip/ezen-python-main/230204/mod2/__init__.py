x = "module test"

def func_1(a, b):
    return a-b